#pragma once
#define GVPLUGIN_CONFIG_FILE "config6"
#define GVPLUGIN_VERSION 6
#define PACKAGE_BUGREPORT "https://gitlab.com/graphviz/graphviz/-/issues"
#define PACKAGE_NAME "graphviz"
#define PACKAGE_STRING "graphviz 8.0.3"
#define PACKAGE_TARNAME "graphviz"
#define PACKAGE_URL ""
#define PACKAGE_VERSION "8.0.3"
